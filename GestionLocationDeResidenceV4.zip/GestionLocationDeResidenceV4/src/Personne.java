import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("3ef293a3-37ff-44c1-952d-647c4ab4e8fd")
public class Personne {
    @objid ("2762a4d4-0b2b-4fd9-b3dd-23cc2a06cb9e")
    public String prenom;

    @objid ("389544d9-ea72-43e2-93da-58178c10bf68")
    public String nom;

    @objid ("60a5491e-09a5-491b-abd3-8288047a3f1e")
    public String email;

    @objid ("8a685086-0a1d-4ee9-a045-83206a95b913")
    public int telephone;

    @objid ("d94f22a0-43c2-42d0-b874-ce1a3a977b5f")
    public String adresse;

}
