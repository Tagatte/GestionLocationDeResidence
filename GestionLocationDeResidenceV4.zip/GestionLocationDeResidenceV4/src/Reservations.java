import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("6afd2138-47ba-46ea-99c7-f0c2b79cbd91")
public class Reservations {
    @objid ("6bbe8b94-0a1d-469f-92f2-05b430231169")
    public String idReservation;

    @objid ("5c5509a8-3c88-4758-9656-6a8b4065d3e3")
    public Date debutReservation;

    @objid ("0cef28bf-6073-40c8-ab88-568e0de260cd")
    public Date finReservation;

    @objid ("52405676-af4c-4966-8d38-9a97dc165715")
    public String montantReservation;

    @objid ("2527de62-cc6c-40e6-b5b6-94820f279307")
    public Locataire ;

    @objid ("a925e17a-fc0e-4b57-8a43-efd69af46572")
    public List<Paiements>  = new ArrayList<Paiements> ();

    @objid ("0dca1503-6843-41e8-a938-33fb2a04d976")
    public List<Materiels>  = new ArrayList<Materiels> ();

    @objid ("42e5b977-6aed-4c99-bbeb-1c94aa3a6050")
    public List<Prestations>  = new ArrayList<Prestations> ();

    @objid ("176a8a81-775d-4f54-9237-86903f9b4698")
    public Logements ;

}
