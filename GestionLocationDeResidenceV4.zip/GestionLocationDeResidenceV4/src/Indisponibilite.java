import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("6125affc-a5c6-454c-94f1-6ddeb1c9e597")
public class Indisponibilite {
    @objid ("5455263c-d238-42e8-adf9-db1bf1859657")
    public String dateDebut;

    @objid ("fb1d52e3-9cb6-4451-bd31-2202f299be63")
    public String dateFin;

    @objid ("1fa0e6b2-2540-407b-ac66-836712cb5762")
    public String contrainte;

    @objid ("31f4f4cc-cb8b-4d92-8940-07a39f8f7aa4")
    public Logements logements;

}
